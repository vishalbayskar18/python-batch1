import pymysql
import db
import sys

dbo = db.Database("localhost", "vishal", "vishal", "shopping2")

while (True):
    userName = input("Enter your your name = ")

    if (dbo.checkIfUserExist(userName) == False):
        print ("In correct user name")
        continue
    else:
        break


print ("Enter the items you want to buy ")


result = dbo.getItemList()

for i in range(len(result)):
    print(i, result[i])

itemNumber = int(input("Enter the item number you wants to buy "))

print("item selected ", result[itemNumber], result[itemNumber][0])

price = dbo.getPrice(result[itemNumber][0])

print ("price = ", price)

dbo.updateUserBalance(userName, price[0])

result = dbo.getUserDetail(userName)

print("User Detail = ", result)
