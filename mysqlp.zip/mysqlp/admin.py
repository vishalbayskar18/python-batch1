import item
import user
from db import Database


dbobject = Database("localhost", "vishal", "vishal", "shopping2")

done = 0

while (done == 0):

    try:
        item1 = item.Item('mobile2', 12000)

        item2 = item.Item('freeze2', 20000)

        #dbobject.addItem( item1)

        #dbobject.addItem( item2)

        user1 = user.User("sachin", "sachin", 50000)

        user2 = user.User("rahul", "rahul", 30000)

        dbobject.addUser(user1)

        dbobject.addUser(user2)

        done = 1 ;
        
    except Exception as e:
        print("Got Exception ", e)
        continue

