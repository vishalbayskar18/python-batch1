class User:
    def __init__(self, name, password, balance):
        self.name = name
        self.password = password
        self.balance = balance