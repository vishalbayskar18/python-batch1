import pymysql
#from item import Item
class Database:
    def __init__(self, hostname, user, password, dbname):
        self.hostname = hostname
        self.user = user
        self.password = password
        self.dbname = dbname
        self.connection = pymysql.connect(host='localhost', port=3306, user=self.user, passwd=self.password, db=self.dbname)
        self.cursor = self.connection.cursor()

    def connect(self):
        pass
        #connection = pymysql.connect(self.hostname, 3306 , self.user, self.password, self.dbname)
        #return cursor

    def addItem(self, item):
        print (item.name, item.price)
        sqlQ = 'insert into item (name, price) values (%s, %s)'

        self.cursor.execute(sqlQ, (item.name, item.price))
        self.connection.commit()

    def addUser(self, user1):
        sqlQ = 'insert into user (name, password, balance) values (%s, %s, %s)'
        self.cursor.execute(sqlQ, (user1.name, user1.password, user1.balance))
        self.connection.commit()

    def getItemList(self):
        sqlQ="select * from item"
        self.cursor.execute(sqlQ)
        return self.cursor.fetchall()

    def getPrice(self, name):
        sqlQ = "select price from item where name = %s"
        self.cursor.execute(sqlQ, (name))
        result = self.cursor.fetchone()
        print("result ", result)
        return result

    def checkIfUserExist(self, userName):
        try:
            sqlQ = "select name from user where name = %s"
            self.cursor.execute(sqlQ, (userName))
            result = self.cursor.fetchone()
            print("result ", result)
            if result == None:
                return False
            else:
                return True

        except Exception as e:
            print("Exception in ", e)


    def updateUserBalance(self, username, price):

        sqlQ = 'select balance from user where name = %s'
        self.cursor.execute(sqlQ, (username))
        balance = self.cursor.fetchone()
        print("balance = ", balance)
        print("balance[0] = ", balance[0])
        newBalance = int(balance[0]) - price

        sqlQ = 'update user set balance = %s where name = %s'
        self.cursor.execute(sqlQ, (newBalance, username))
        self.connection.commit()

    def getUserDetail(self, userName):

        sqlQ = "select * from user where name = %s"
        self.cursor.execute(sqlQ, (userName))
        result = self.cursor.fetchone()
        print("result ", result)
        if result == None:
            return False
        else:
            return result