import sqlite3

class DatabaseSQlite:
    def __init__(self, databaseName):
        self.connection = sqlite3.connect(databaseName)
        self.cursor = self.connection.cursor()

    def addItem(self, item):
        sqlQuery = 'insert into item (name, price ) values (?, ?)'
        try :
            self.cursor.execute(sqlQuery, (item.name, item.price))
            self.connection.commit()
        except Exception as e:
            print("Got Exception while adding user ", e)

    def addUser(self, user):
        sqlQuery = 'insert into user (name, password, balance) values (?, ?, ?)'
        try:
            self.cursor.execute(sqlQuery, (user.name, user.password, user.balance))
            self.connection.commit()
        except Exception as e:
            print("Got Exception while adding user ", e)

    def checkIfUserExist(self, name):
        try:
            sqlQuery = 'select name from user where name = ?'
            self.cursor.execute(sqlQuery, (name,))
            result = self.cursor.fetchone()
            print ("result = ", result)
        except Exception as e:
            print ("Got Exception ", e)

        if result:
            return True
        else:
            return False

    def validatePassword(self, name, password):
        try:
            sqlQuery = 'select password from user where name = ?'
            self.cursor.execute(sqlQuery, (name,))
            result = self.cursor.fetchone()
            print ("password result = ", result)
            print("password result = ", result[0])
        except Exception as e:
            print ("Got Exception ", e)

        if result[0] == password:
            return True
        else:
            return False

    def getAllitem(self):
        try:
            sqlQuery = 'select * from item'
            self.cursor.execute(sqlQuery)
            result = self.cursor.fetchall()
            print("result = ", result)

        except Exception as e:
            print("Got Exception ", e)

        return result