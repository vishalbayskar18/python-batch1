import sqlite3

connection = sqlite3.connect("shopping")

userTable = 'create table user (name varchar(30), ' \
            'password varchar(30), balance int, ' \
            'primary key (name))'

itemTable = 'create table item (name varchar(30), price int,' \
            'primary key (name))'

connection.execute(userTable)
connection.execute(itemTable)

connection.commit()
