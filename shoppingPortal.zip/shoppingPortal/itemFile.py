class item:
    def __init__(self, n, p):
        self.name = n
        self.price = p