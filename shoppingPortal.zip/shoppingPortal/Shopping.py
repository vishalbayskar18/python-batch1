from DatabaseFile2 import DatabaseSQlite
import Constant

dbObject = DatabaseSQlite(Constant.DATABASE_NAME)

while True:
    userName = input("Enter your name ")
    result = dbObject.checkIfUserExist(userName)
    #if result == True:
    if result:
        break
    else:
        print ('User Name is not Valid ', userName)
        continue


while True:
    password = input("Enter your password ")
    result = dbObject.validatePassword(userName, password)
    #if result == True:
    if result:
        break
    else:
        print ('password  is not Valid ', userName)
        continue

print ("select the items from below list ")
itemList = dbObject.getAllitem()
for item in itemList:
    print (item[0], item[1])

itemInput = input ("Write the item name which you want to buy")

#userBalance

#Update user balance
#Current balance = balance - price







