from itemFile import item
from userFile import user
from DatabaseFile2 import DatabaseSQlite

u1 = user("P Gopichund", "gopichand", 50000)
u2 = user("P Sindhu", "sindhu", 30000)

i1 = item("Racket", 1000)
i2 = item("Badminton shuttle", 100)

dbOjbect = DatabaseSQlite("shopping")

dbOjbect.addUser(u1)

dbOjbect.addUser(u2)

dbOjbect.addItem(i1)
dbOjbect.addItem(i2)









