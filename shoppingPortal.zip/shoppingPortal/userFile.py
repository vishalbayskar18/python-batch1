class user:
    def __init__(self, n, p, b):

        self.name = n
        self.password = p
        self.balance = b